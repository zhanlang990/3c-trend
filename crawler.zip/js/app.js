(function () {
  "use strict";

  var DATA_URL = "./data/news.json";

  var state = {
    all: [],
    source: "",
    query: "",
  };

  var $list = document.getElementById("news-list");
  var $empty = document.getElementById("empty-state");
  var $filter = document.getElementById("source-filter");
  var $search = document.getElementById("search-input");
  var $total = document.getElementById("stat-total");
  var $sources = document.getElementById("stat-sources");
  var $time = document.getElementById("stat-time");

  function escapeHtml(s) {
    if (s == null) return "";
    var div = document.createElement("div");
    div.textContent = String(s);
    return div.innerHTML.replace(/"/g, "&#34;").replace(/'/g, "&#39;");
  }

  function uniqueSources(items) {
    var set = {};
    items.forEach(function (it) {
      if (it.source) set[it.source] = true;
    });
    return Object.keys(set);
  }

  function renderFilter(sources) {
    // keep the "全部" chip, add per-source chips
    var html = '<button class="chip chip-active" data-source="">全部</button>';
    sources.forEach(function (s) {
      html += '<button class="chip" data-source="' + escapeHtml(s) + '">' + escapeHtml(s) + "</button>";
    });
    $filter.innerHTML = html;
    Array.prototype.forEach.call($filter.querySelectorAll(".chip"), function (btn) {
      btn.addEventListener("click", function () {
        state.source = btn.getAttribute("data-source") || "";
        Array.prototype.forEach.call($filter.querySelectorAll(".chip"), function (b) {
          b.classList.toggle("chip-active", b === btn);
        });
        applyFilters();
      });
    });
  }

  function renderStats(data) {
    $total.textContent = data.total != null ? data.total : (data.items || []).length;
    $sources.textContent = data.source_count != null ? data.source_count : uniqueSources(data.items || []).length;
    $time.textContent = data.generated_at || "--";
  }

  function cardHtml(it) {
    var url = it.url || "#";
    var insight = it.procurement_insight || "";
    var summary = it.summary || "";
    return (
      '<a class="news-card" href="' + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer">' +
        '<div class="news-meta">' +
          '<span class="news-source">' + escapeHtml(it.source || "未知来源") + "</span>" +
          '<span class="news-date">' + escapeHtml(it.publish_date || "") + "</span>" +
        "</div>" +
        '<h3 class="news-title">' + escapeHtml(it.title || "") + "</h3>" +
        (summary ? '<p class="news-summary">' + escapeHtml(summary) + "</p>" : "") +
        (insight
          ? '<div class="news-insight">' +
              '<span class="news-insight-tag">💡 采销建议</span>' +
              escapeHtml(insight) +
            "</div>"
          : "") +
      "</a>"
    );
  }

  function renderList(items) {
    if (!items.length) {
      $list.innerHTML = "";
      $empty.hidden = false;
      return;
    }
    $empty.hidden = true;
    $list.innerHTML = items.map(cardHtml).join("");
  }

  function applyFilters() {
    var src = state.source;
    var q = (state.query || "").trim().toLowerCase();
    var filtered = state.all.filter(function (it) {
      if (src && it.source !== src) return false;
      if (q) {
        var hay = ((it.title || "") + " " + (it.summary || "")).toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });
    renderList(filtered);
  }

  function init(data) {
    state.all = (data && data.items) || [];
    renderStats(data || {});
    renderFilter(uniqueSources(state.all));
    renderList(state.all);
    $search.addEventListener("input", function () {
      state.query = $search.value || "";
      applyFilters();
    });
  }

  function loadJson(url) {
    return fetch(url, { cache: "no-store" }).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
  }

  loadJson(DATA_URL)
    .catch(function () { return loadJson("./data/news.sample.json"); })
    .then(init)
    .catch(function (err) {
      $list.innerHTML = "";
      $empty.hidden = false;
      $empty.querySelector("p").textContent = "新闻数据加载失败 😢";
      $empty.querySelector(".empty-tip").textContent = "请检查 data/news.json 是否存在或网络是否通畅：" + err.message;
    });
})();